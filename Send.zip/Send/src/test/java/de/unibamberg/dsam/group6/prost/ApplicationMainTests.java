package de.unibamberg.dsam.group6.prost;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationMainTests {

    @Test
    void contextLoads() {}
}
